package com.example.proyecto

class ModelSlider {
    var link: String = ""

    constructor()
    constructor( link: String) {

        this.link = link
    }


}
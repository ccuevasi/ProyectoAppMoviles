package com.example.proyecto

class ModelImages {

    var link: String = ""

    constructor()
    constructor(link: String) {
        this.link = link
    }

}